package MainCodeBase;

public class FakeMain {
    public static void main(String []args){
        MainCodeBase.Main.main(args);
    }
}
